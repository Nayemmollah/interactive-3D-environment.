# https---github.com-ShajibEwuCse19-3D-Solar-System-Design-Using-OpenGL
How to run the project:
-> Install Virtual Community Edition 2022. <br/>
   Link: https://visualstudio.microsoft.com/thank-you-downloading-visual-studio/?sku=Community&channel=Release&version=VS2022&source=VSLandingPage&passive=false&cid=2030   
-> Open 'Solar System using OpenGL' dir. <br/>
-> Click 'OpenGLProject.sln' for simulation. <br/>
-> Run the code. <br/>
-> W, S, A, D for zoom in, zoom out, left, right control.  <br/>
-> Press 'ESC' to close. <br/>
